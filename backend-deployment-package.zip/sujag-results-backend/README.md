# SUJAG Education Results Backend

Flask API with PostgreSQL persistence and optional SQLite fallback for local development.

## Deploy (no Cloudflare)
1. Create a GitHub repository and upload these files.
2. On Render, choose **New > Blueprint**, connect the repo containing `render.yaml`.
3. Review the blueprint and deploy. It provisions a web service and PostgreSQL database.
4. In the service Environment settings, set `ALLOWED_ORIGINS` to your exact public site origin, e.g. `https://MYNAME.github.io` (or blank to disable origin restriction). The POST endpoint is public by contract, and origin restrictions are not a substitute for authentication.
5. Copy the Render service URL (the base URL).

ADMIN_KEY: Set the `ADMIN_KEY` environment variable in Render to your chosen long secret before/while deploying. Never publish the key or put it in client-side site code.

## API
- POST / : raw JSON accepted irrespective of content type; public
- GET /?action=list&key=... : admin listing
- GET /?action=delete&id=...&key=... : admin delete
- DELETE /?id=... : delete with X-Admin-Key
- GET / : health/status

## cURL examples (replace BASE_URL)
Health:
`curl -i BASE_URL/`

Submit:
`curl -i -X POST BASE_URL/ -H 'Content-Type: text/plain;charset=UTF-8' --data '{"rid":"attempt-001","testId":"sample","title":"Sample Test","category":"Demo","name":"Candidate","city":"Karachi","phone":"","total":10,"correct":8,"wrong":1,"unanswered":1,"marks":8,"percent":80,"timeTaken":120,"duration":10,"auto":false}'`

List:
`curl -i 'BASE_URL/?action=list&key=ADMIN_KEY'`

Delete via GET:
`curl -i 'BASE_URL/?action=delete&id=RESULT_ID&key=ADMIN_KEY'`

Delete via DELETE:
`curl -i -X DELETE 'BASE_URL/?id=RESULT_ID' -H 'X-Admin-Key: ADMIN_KEY'`

Export: PostgreSQL data is stored in the managed database. Use Render's database dashboard / connection details and a PostgreSQL client (pg_dump) to export a backup. Free-tier database retention/availability policies may change; verify current plan limitations before relying on it for long-term storage.
