import os, json, time, uuid, math
from collections import defaultdict, deque
from urllib.parse import parse_qs
from flask import Flask, request, jsonify, Response
from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError

app=Flask(__name__)
ADMIN_KEY=os.environ.get("ADMIN_KEY","")
if not ADMIN_KEY: raise RuntimeError("ADMIN_KEY environment variable is required")
ALLOWED=[x.strip() for x in os.environ.get("ALLOWED_ORIGINS","").split(",") if x.strip()]
dburl=os.environ.get("DATABASE_URL","sqlite:///results.db")
if dburl.startswith("postgres://"): dburl=dburl.replace("postgres://","postgresql://",1)
engine=create_engine(dburl, pool_pre_ping=True)
rate=defaultdict(deque)

def init():
  with engine.begin() as c:
    c.execute(text("""CREATE TABLE IF NOT EXISTS results (
      id TEXT PRIMARY KEY, rid TEXT UNIQUE, at BIGINT, testId TEXT, title TEXT, category TEXT,
      name TEXT, city TEXT, phone TEXT, total INTEGER, correct INTEGER, wrong INTEGER,
      unanswered INTEGER, marks REAL, percent REAL, timeTaken INTEGER, duration INTEGER, auto BOOLEAN
    )"""))
init()

def trim(v,n):
  if v is None: return ""
  return str(v).strip()[:n]
def num(v, default=0, lo=0, hi=100000):
  try: x=float(v)
  except: x=default
  return max(lo,min(hi,x))
def ip():
  # Prefer platform-provided remote IP; do not trust arbitrary XFF unless hosting config does.
  return request.remote_addr or "unknown"
def rate_ok():
  now=time.time(); q=rate[ip()]
  while q and q[0] < now-60: q.popleft()
  if len(q)>=20: return False
  q.append(now); return True
def admin_ok():
  k=request.headers.get("X-Admin-Key") or request.args.get("key","")
  return bool(k) and secrets_compare(k,ADMIN_KEY)
def secrets_compare(a,b):
  import hmac
  return hmac.compare_digest(str(a),str(b))

@app.after_request
def cors(resp):
  origin=request.headers.get("Origin","")
  resp.headers["Access-Control-Allow-Origin"]="*" if not ALLOWED or origin in ALLOWED else (origin if origin in ALLOWED else "*")
  resp.headers["Access-Control-Allow-Methods"]="GET, POST, DELETE, OPTIONS"
  resp.headers["Access-Control-Allow-Headers"]="Content-Type, X-Admin-Key"
  resp.headers["Access-Control-Max-Age"]="86400"
  return resp

@app.route("/", methods=["OPTIONS"])
def options(): return Response(status=204)

@app.route("/", methods=["POST"])
def add():
  if ALLOWED:
    origin=request.headers.get("Origin","")
    if origin and origin not in ALLOWED: return jsonify(ok=False),403
  if not rate_ok(): return jsonify(error="Rate limit exceeded."),429
  raw=request.get_data(as_text=True)
  try: d=json.loads(raw)
  except: return jsonify(error="Invalid JSON."),400
  name=trim(d.get("name"),60); testId=trim(d.get("testId"),80)
  try: total=int(num(d.get("total"),0,0,100000))
  except: total=0
  if not name or not testId or total<1: return jsonify(error="name, testId and positive total are required."),400
  rid=trim(d.get("rid"),200) or str(uuid.uuid4())
  vals={
    "id":str(uuid.uuid4()),"rid":rid,"at":int(time.time()*1000),"testId":testId,
    "title":trim(d.get("title"),90),"category":trim(d.get("category"),60),
    "name":name,"city":trim(d.get("city"),40),"phone":trim(d.get("phone"),20),
    "total":total,"correct":int(num(d.get("correct"),0,0,total)),
    "wrong":int(num(d.get("wrong"),0,0,total)),"unanswered":int(num(d.get("unanswered"),0,0,total)),
    "marks":num(d.get("marks"),0,-100000,100000),"percent":num(d.get("percent"),0,0,100),
    "timeTaken":int(num(d.get("timeTaken"),0,0,86400*30)),
    "duration":int(num(d.get("duration"),0,0,10080)),"auto":bool(d.get("auto",False))
  }
  try:
    with engine.begin() as c:
      c.execute(text("""INSERT INTO results (id,rid,at,testId,title,category,name,city,phone,total,correct,wrong,unanswered,marks,percent,timeTaken,duration,auto)
      VALUES (:id,:rid,:at,:testId,:title,:category,:name,:city,:phone,:total,:correct,:wrong,:unanswered,:marks,:percent,:timeTaken,:duration,:auto)"""),vals)
  except IntegrityError:
    return jsonify(ok=True) # duplicate rid ignored
  return jsonify(ok=True)

@app.route("/", methods=["GET","DELETE"])
def get():
  action=request.args.get("action")
  if request.method=="DELETE" or action=="delete":
    if not admin_ok(): return jsonify(error="Wrong or missing admin key."),401
    rid=request.args.get("id","")
    if not rid and request.method=="DELETE": rid=request.args.get("id","")
    with engine.begin() as c: c.execute(text("DELETE FROM results WHERE id=:id"),{"id":rid})
    return jsonify(ok=True)
  if action=="list":
    if not admin_ok(): return jsonify(error="Wrong or missing admin key."),401
    with engine.connect() as c:
      rows=c.execute(text("SELECT id,at,testId,title,category,name,city,phone,total,correct,wrong,unanswered,marks,percent,timeTaken,duration,auto,rid FROM results ORDER BY at DESC")).mappings().all()
    return jsonify(results=[dict(r) for r in rows],cursor="")
  return jsonify(ok=True,service="SUJAG results",kv=True,adminKey=True)

if __name__=="__main__":
  app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8080")))
